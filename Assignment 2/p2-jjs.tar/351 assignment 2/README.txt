– Your name and email address.
Jason Liu - jliu96@csu.fullerton.edu
Joshua Elmer - joshuaelmer@csu.fullerton.edu
Syeda Nida Khader - syedanida@csu.fullerton.edu

– The programming language you used (i.e., C or C++).
C++

– How to execute your program.
make
./recv
./sender keyfile.txt

– Whether you implemented the extra credit.


– Anything special about your submission that we should take note of.
